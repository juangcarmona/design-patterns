using Xunit;

public class FactoryMethodTests {
    [Fact]
    public void TestFactoryMethod() {
        // Arrange
        
        // Act
        
        // Assert
        Assert.True(true);
    }
}