using Xunit;

public class BuilderTests {
    [Fact]
    public void TestBuilder() {
        // Arrange
        
        // Act
        
        // Assert
        Assert.True(true);
    }
}