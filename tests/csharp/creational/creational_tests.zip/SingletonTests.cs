using Xunit;

public class SingletonTests {
    [Fact]
    public void TestSingleton() {
        // Arrange
        
        // Act
        
        // Assert
        Assert.True(true);
    }
}